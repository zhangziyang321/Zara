﻿using GalaSoft.MvvmLight;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Imaging;

namespace Graduation
{
    public class MainModel: ViewModelBase
    {
        private string _email;
        /// <summary>
        /// Email
        /// </summary>
        public string Email
        {
            get { return _email; }
            set
            {
                _email = value.Trim();
               
                RaisePropertyChanged("Email");
            }
        }
        private string _emailTxt;
        /// <summary>
        ///  
        /// </summary>
        public string EmailTxt
        {
            get { return _emailTxt; }
            set
            {
                _emailTxt = value;
                if (!string.IsNullOrEmpty(Email))
                {
                    if (!IsEmail(Email))
                    {
                        Email = "not email";
                        MessageBox.Show("邮箱地址不正确");
                       
                    }
                }
                RaisePropertyChanged();
            }
        }
        private string _PictureFilePath;
        /// <summary>
        ///  
        /// </summary>
        public string PictureFilePath
        {
            get { return _PictureFilePath; }
            set
            {
                _PictureFilePath = value;
                RaisePropertyChanged();
            }
        }
        private BitmapImage _PictureFileName;

        /// <summary>
        /// =
        /// </summary>
        public BitmapImage PictureFileName
        {
            get { return _PictureFileName; }
            set
            {
                _PictureFileName = value;
                RaisePropertyChanged();
            }
        }

        public bool IsEmail(string str_Email)
        {
            try
            {
                return System.Text.RegularExpressions.Regex.IsMatch(str_Email, @"^\\s*([A-Za-z0-9_-]+(\\.\\w+)*@(\\w+\\.)+\\w{2,5})\\s*$");

            }
            catch (Exception ex)
            {

                throw;
            }

        }
    }
}
