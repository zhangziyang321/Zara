using System;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Media.Imaging;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using Microsoft.Win32;

namespace Graduation.ViewModel
{

    public class MainViewModel : ViewModelBase
    {

        private RelayCommand<Window> _exit;
        /// <summary>
        /// �ر�ҳ
        /// </summary>
        public RelayCommand<Window> ExitCommand
        {
            get
            {
                if (_exit == null)
                {
                    _exit = new RelayCommand<Window>((wd) =>
                    {
                        if (wd != null)
                        {
                            wd.Close();
                        }
                    });
                }
                return _exit;
            }
            set { _exit = value; }
        }
        private RelayCommand _QueryCommand;

        /// <summary>
        /// ѡ��
        /// </summary>
        public RelayCommand SelectCommand
        {
            get
            {
                if (_QueryCommand == null)
                {
                    _QueryCommand = new RelayCommand(() => select());
                }
                return _QueryCommand;
            }
            set { _QueryCommand = value; }
        }
    
        private MainModel _pageollection = new MainModel();

        /// <summary>
        /// ҳ�����ݽ�������
        /// </summary>
        public MainModel PageCollection
        {
            get { return _pageollection; }
            set
            {
                _pageollection = value;
                RaisePropertyChanged();
            }
        }
        

        public MainViewModel()
        {
            
        }
        /// <summary>
        /// ѡ��ͼƬ
        /// </summary>
        private void select()
        {
            try
            {
                OpenFileDialog openfiledialog = new OpenFileDialog
                {
                    Filter = "ͼ���ļ�|*.jpg;*.png;*.jpeg;*.bmp;*.gif|�����ļ�|*.*"
                };

                if ((bool)openfiledialog.ShowDialog())
                {
                    PageCollection.PictureFileName = new BitmapImage(new Uri(openfiledialog.FileName));
                    PageCollection.PictureFilePath = openfiledialog.FileName;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

       
    }
}